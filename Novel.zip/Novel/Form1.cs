using System.Drawing.Text;

namespace Novel
{
    public partial class Form1 : Form
    {
        #region Custom font
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        private static extern IntPtr AddFontMemResourceEx(IntPtr pbFont, uint cbFont, IntPtr pdv, [System.Runtime.InteropServices.In] ref uint pcFonts);

        private PrivateFontCollection fonts = new PrivateFontCollection();

        Font ChronoTypeFontRegular;
        #endregion

        int story = 0;
        string character;
        bool animating = false;

        public Form1()
        {
            InitializeComponent();
            SetTransperency();

            #region Custom font
            byte[] fontData = Properties.Resources.ChronoType;
            IntPtr fontPtr = System.Runtime.InteropServices.Marshal.AllocCoTaskMem(fontData.Length);
            System.Runtime.InteropServices.Marshal.Copy(fontData, 0, fontPtr, fontData.Length);
            uint dummy = 0;
            fonts.AddMemoryFont(fontPtr, Properties.Resources.ChronoType.Length);
            AddFontMemResourceEx(fontPtr, (uint)Properties.Resources.ChronoType.Length, IntPtr.Zero, ref dummy);
            System.Runtime.InteropServices.Marshal.FreeCoTaskMem(fontPtr);

            ChronoTypeFontRegular = new Font(fonts.Families[0], 14.0F);
            characterTextLabel.Font = ChronoTypeFontRegular;
            ChronoTypeFontRegular = new Font(fonts.Families[0], 40.0F);
            startLabel.Font = ChronoTypeFontRegular;
            #endregion
        }

        private async void startLabel_Click(object sender, EventArgs e)
        {
            backPictureBox.Image = Properties.Resources.Scene_1_Normal;
            startLabel.Visible = false;

            bottomPanel.Visible = true;
            characterImagePicBox.Image = Properties.Resources.Crono_icon_Round;

            StoryStep();
        }

        private async void StoryStep()
        {
            if (animating)
                return;

            switch (story)
            {
                case 0:
                    story++;
                    characterTextLabel.Text = "";
                    animating = true;
                    await Print("Crono: I'll go gather some wood for a campfire, who wants to come with me?", characterTextLabel);
                    animating = false;
                    break;
                case 1:
                    story++;
                    frogPointer.Visible =
                    roboPointer.Visible =
                    marlePointer.Visible =
                    magusPointer.Visible =
                    aylaPointer.Visible =
                    luccaPointer.Visible = true;
                    characterImagePicBox.Image = null;
                    characterTextLabel.Text = "";
                    animating = true;
                    await Print("Choose character", characterTextLabel);
                    animating = false;
                    break;
                case 3:
                    story++;
                    characterTextLabel.Text = "";
                    backPictureBox.Image = Properties.Resources.Scene_2_Normal;
                    SetSideCharacters();
                    characterImagePicBox.Image = Properties.Resources.Crono_icon_Round;
                    animating = true;
                    await Print($"Crono: Hey {character}, what you plan to do when we finish with Lavos?", characterTextLabel);
                    animating = false;
                    break;
                case 4:
                    characterTextLabel.Text = "";
                    SetCharacterIcon();
                    PrintCharacterDialogue();
                    story++;
                    break;
                case 5:
                    characterTextLabel.Text = "";
                    characterImagePicBox.Image = Properties.Resources.Crono_icon_Round;
                    PrintCronoReply();
                    story++;
                    break;
                case 6:
                    characterTextLabel.Text = "";
                    SetCharacterIcon();
                    animating = true;
                    await PrintCharacterDialogue();
                    animating = false;
                    story++;
                    break;
                case 7:
                    story = 0;
                    SetStartScreen();
                    break;
            }
        }

        private void SetStartScreen()
        {
            rightPictureBox.Visible = false;
            leftPictureBox.Visible = false;
            bottomPanel.Visible = false;
            backPictureBox.Image = Properties.Resources.Title_Screen_Normal;
            startLabel.Visible = true;
        }

        private void SetSideCharacters()
        {
            Random rand = new Random();
            rightPictureBox.Visible = true;
            leftPictureBox.Visible = true;
            int choice = rand.Next(2);
            if (choice == 0)
                leftPictureBox.Image = Properties.Resources.Crono_left;
            else
                rightPictureBox.Image = Properties.Resources.Crono_right;

            switch (character)
            {
                case "Magus":
                    if (choice == 0)
                        rightPictureBox.Image = Properties.Resources.Magus_right;
                    else
                        leftPictureBox.Image = Properties.Resources.Magus_left;
                    break;
                case "Frog":
                    if (choice == 0)
                        rightPictureBox.Image = Properties.Resources.Frog_right;
                    else
                        leftPictureBox.Image = Properties.Resources.Frog_left;
                    break;
                case "Lucca":
                    if (choice == 0)
                        rightPictureBox.Image = Properties.Resources.Lucca_right;
                    else
                        leftPictureBox.Image = Properties.Resources.Lucca_left;
                    break;
                case "Marle":
                    if (choice == 0)
                        rightPictureBox.Image = Properties.Resources.marle_right;
                    else
                        leftPictureBox.Image = Properties.Resources.marle_left;
                    break;
                case "Robo":
                    if (choice == 0)
                        rightPictureBox.Image = Properties.Resources.Robo_right;
                    else
                        leftPictureBox.Image = Properties.Resources.Robo_left;
                    break;
                case "Ayla":
                    if (choice == 0)
                        rightPictureBox.Image = Properties.Resources.Ayla_right;
                    else
                        leftPictureBox.Image = Properties.Resources.Ayla_left;
                    break;
            }
        }

        private async Task PrintCharacterDialogue()
        {
            characterTextLabel.Text = "";
            SetCharacterIcon();
            switch (character)
            {
                case "Magus":
                    switch (story)
                    {
                        case 4:
                            animating = true;
                            await Print($"{character}: I plan to return in my time and see what will happen to Kingdom of Zeal", characterTextLabel);
                            animating = false;
                            break;
                        case 6:
                            animating = true;
                            await Print($"{character}: Thanks Crono, let's go back", characterTextLabel);
                            animating = false;
                            break;
                    }
                    break;
                case "Frog":
                    switch (story)
                    {
                        case 4:
                            animating = true;
                            await Print($"{character}: I will return to my time and serve my kingdom as Cyrus did ", characterTextLabel);
                            animating = false;
                            break;
                        case 6:
                            animating = true;
                            await Print($"{character}: Thanks Crono, you became an amazing swordsman and let's go back we got what we came for", characterTextLabel);
                            animating = false;
                            break;
                    }
                    break;
                case "Lucca":
                    switch (story)
                    {
                        case 4:
                            animating = true;
                            await Print($"{character}: When we return to our time, I will keep inventing stuff with my dad to help people", characterTextLabel);
                            animating = false;
                            break;
                        case 6:
                            animating = true;
                            await Print($"{character}: Thanks Crono, hope I will get some help from you with them and let's go back, we got what we needed", characterTextLabel);
                            animating = false;
                            break;
                    }
                    break;
                case "Marle":
                    switch (story)
                    {
                        case 4:
                            animating = true;
                            await Print($"{character}: I want to talk with my father about our adventure and so much more, I need some time to think about it", characterTextLabel);
                            animating = false;
                            break;
                        case 6:
                            animating = true;
                            await Print($"{character}: I don't know that you were a moms' boy,  everyone is waiting, so let's go back", characterTextLabel);
                            animating = false;
                            break;
                    }
                    break;
                case "Robo":
                    switch (story)
                    {
                        case 4:
                            animating = true;
                            await Print($"{character}: I want to see how future will change after Lavos death", characterTextLabel);
                            animating = false;
                            break;
                        case 6:
                            animating = true;
                            await Print($"{character}: Thanks Crono, you are saver of time and let's go back", characterTextLabel);
                            animating = false;
                            break;
                    }
                    break;
                case "Ayla":
                    switch (story)
                    {
                        case 4:
                            animating = true;
                            await Print($"{character}: Ayla go home, Ayla eat, Ayla sleep, Ayla marry Kino, Ayla happy", characterTextLabel);
                            animating = false;
                            break;
                        case 6:
                            animating = true;
                            await Print($"{character}: Ayla thank Crono, Ayla go back", characterTextLabel);
                            animating = false;
                            break;
                    }
                    break;
            }
        }

        private async void PrintCronoReply()
        {
            characterTextLabel.Text = "";
            switch (character)
            {
                case "Magus":
                    animating = true;
                    await Print("Crono: I see, hope it'll be okay without Lavos that screwed up your mother", characterTextLabel);
                    animating = false;
                    break;
                case "Frog":
                    animating = true;
                    await Print("Crono: I am glad that you have forgiven yourself and can live your life without regrets", characterTextLabel);
                    animating = false;
                    break;
                case "Lucca":
                    animating = true;
                    await Print("Crono: That's nice, I'll be looking for it", characterTextLabel);
                    animating = false;
                    break;
                case "Marle":
                    animating = true;
                    await Print("Crono: That's nice, I can't wait to see my mom again too", characterTextLabel);
                    animating = false;
                    break;
                case "Robo":
                    animating = true;
                    await Print("Crono: I believe it will be good", characterTextLabel);
                    animating = false;
                    break;
                case "Ayla":
                    animating = true;
                    await Print("Crono: Haha, That`s great", characterTextLabel);
                    animating = false;
                    break;
            }
        }

        private async Task Print(string text, Label output)
        {
            if (output is null)
                return;

            foreach (var ch in text)
            {
                output.Text += ch;
                await Task.Delay(50);
            }
        }

        private void SetTransperency()
        {
            var pos = startLabel.Parent.PointToScreen(startLabel.Location);
            pos = backPictureBox.PointToClient(pos);
            startLabel.Parent = backPictureBox;
            startLabel.Location = pos;
            startLabel.BackColor = Color.Transparent;

            pos = bottomPanel.Parent.PointToScreen(bottomPanel.Location);
            pos = backPictureBox.PointToClient(pos);
            bottomPanel.Parent = backPictureBox;
            bottomPanel.Location = pos;
            bottomPanel.BackColor = Color.Transparent;

            pos = characterTextLabel.Parent.PointToScreen(characterTextLabel.Location);
            pos = backgroudTextPicBox.PointToClient(pos);
            characterTextLabel.Parent = backgroudTextPicBox;
            characterTextLabel.Location = pos;
            characterTextLabel.BackColor = Color.Transparent;

            pos = characterImagePicBox.Parent.PointToScreen(characterImagePicBox.Location);
            pos = backgroudTextPicBox.PointToClient(pos);
            characterImagePicBox.Parent = backgroudTextPicBox;
            characterImagePicBox.Location = pos;
            characterImagePicBox.BackColor = Color.Transparent;

            pos = leftPictureBox.Parent.PointToScreen(leftPictureBox.Location);
            pos = backPictureBox.PointToClient(pos);
            leftPictureBox.Parent = backPictureBox;
            leftPictureBox.Location = pos;
            leftPictureBox.BackColor = Color.Transparent;

            pos = rightPictureBox.Parent.PointToScreen(rightPictureBox.Location);
            pos = backPictureBox.PointToClient(pos);
            rightPictureBox.Parent = backPictureBox;
            rightPictureBox.Location = pos;
            rightPictureBox.BackColor = Color.Transparent;

            pos = frogPointer.Parent.PointToScreen(frogPointer.Location);
            pos = backPictureBox.PointToClient(pos);
            frogPointer.Parent = backPictureBox;
            frogPointer.Location = pos;
            frogPointer.BackColor = Color.Transparent;

            pos = aylaPointer.Parent.PointToScreen(aylaPointer.Location);
            pos = backPictureBox.PointToClient(pos);
            aylaPointer.Parent = backPictureBox;
            aylaPointer.Location = pos;
            aylaPointer.BackColor = Color.Transparent;

            pos = magusPointer.Parent.PointToScreen(magusPointer.Location);
            pos = backPictureBox.PointToClient(pos);
            magusPointer.Parent = backPictureBox;
            magusPointer.Location = pos;
            magusPointer.BackColor = Color.Transparent;

            pos = marlePointer.Parent.PointToScreen(marlePointer.Location);
            pos = backPictureBox.PointToClient(pos);
            marlePointer.Parent = backPictureBox;
            marlePointer.Location = pos;
            marlePointer.BackColor = Color.Transparent;

            pos = luccaPointer.Parent.PointToScreen(luccaPointer.Location);
            pos = backPictureBox.PointToClient(pos);
            luccaPointer.Parent = backPictureBox;
            luccaPointer.Location = pos;
            luccaPointer.BackColor = Color.Transparent;

            pos = roboPointer.Parent.PointToScreen(roboPointer.Location);
            pos = backPictureBox.PointToClient(pos);
            roboPointer.Parent = backPictureBox;
            roboPointer.Location = pos;
            roboPointer.BackColor = Color.Transparent;

        }

        private void backPictureBox_Click(object sender, EventArgs e)
        {
            StoryStep();
        }

        private void marlePointer_Click(object sender, EventArgs e)
        {
            character = "Marle";
            CharacterChosen();
        }

        private void frogPointer_Click(object sender, EventArgs e)
        {
            character = "Frog";
            CharacterChosen();
        }

        private void roboPointer_Click(object sender, EventArgs e)
        {
            character = "Robo";
            CharacterChosen();
        }

        private void luccaPointer_Click(object sender, EventArgs e)
        {
            character = "Lucca";
            CharacterChosen();
        }

        private void aylaPointer_Click(object sender, EventArgs e)
        {
            character = "Ayla";
            CharacterChosen();
        }

        private void magusPointer_Click(object sender, EventArgs e)
        {
            character = "Magus";
            CharacterChosen();
        }

        private async void CharacterChosen()
        {
            story++;

            frogPointer.Visible =
            roboPointer.Visible =
            marlePointer.Visible =
            magusPointer.Visible =
            aylaPointer.Visible =
            luccaPointer.Visible = false;

            SetCharacterIcon();

            if (character == "Ayla")
            {
                characterTextLabel.Text = "";
                animating = true;
                await Print($"{character}: Ayla wood go", characterTextLabel);
                animating = false;
            }
            else
            {
                characterTextLabel.Text = "";
                animating = true;
                await Print($"{character}: Let's go Crono", characterTextLabel);
                animating = false;
            }
            backPictureBox.Enabled = true;
        }

        private void SetCharacterIcon()
        {
            switch (character)
            {
                case "Magus":
                    characterImagePicBox.Image = Properties.Resources.Magus_icon_Round;
                    break;
                case "Frog":
                    characterImagePicBox.Image = Properties.Resources.Frog_icon_Round;
                    break;
                case "Lucca":
                    characterImagePicBox.Image = Properties.Resources.Lucca_icon_Round;
                    break;
                case "Marle":
                    characterImagePicBox.Image = Properties.Resources.Marle_icon_Round;
                    break;
                case "Robo":
                    characterImagePicBox.Image = Properties.Resources.Robo_icon_Round;
                    break;
                case "Ayla":
                    characterImagePicBox.Image = Properties.Resources.Ayla_icon_Round;
                    break;
            }
        }
    }
}